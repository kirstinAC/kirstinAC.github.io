ArtCenter Dot for Print Use

Use CMYK and PMS files for process color or spot color printing, respectively.